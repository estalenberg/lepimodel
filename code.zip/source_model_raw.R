
  #code#####
    gmultmin=1.1#input$postureInput[1] #1.3
    gmultmax=3#input$postureInput[2]#3
    furdepth=19*(input$furdInput/100) # mm
    O2eff=0.2 
    
    FC_m18=as.numeric(mins$FC_m18[mins$cat==category])
    Q10_m18=as.numeric(mins$q10_m18[mins$cat==category])
    tamin18=as.numeric(mins$ta_m18[mins$cat==category])
  
    tamin=tamin18
    furcond=FC_m18
    q10=Q10_m18
    
    furcond=furcond*(input$furcInput/100)
    q10=q10*(input$qInput/100)
    
    sexa=as.numeric(mins$sex[mins$cat==category])
    seasa=as.numeric(mins$seas[mins$cat==category])
    mass=(as.numeric(mins$massg[mins$cat==category]))/1000
    mass=mass*(input$massInput/100)
    speaka=(mass*1000)^0.668
    
    #body temp
    ta=seq(10,46,by=1)
    ta=ta+input$tempInput
    tbmin=(36.00289 + (-0.18903*tamin) + (-0.16238*sexa) + (0.00587*(tamin^2)) + (-1.22523*seasa) + (-0.00046*sexa*(tamin^2)) + (0.0014*(tamin^2)*seasa)) 
    tb= ifelse(ta <= tamin,tbmin,(36.00289 + (-0.18903*ta) + (-0.16238*sexa) + 0.00587*(ta^2) + (-1.22523*seasa) + (-0.00046*sexa*(ta^2)) + (0.0014*(ta^2)*seasa)) )
    tbc=(36.00289 + (-0.18903*ta) + (-0.16238*sexa) + 0.00587*(ta^2) + (-1.22523*seasa) + (-0.00046*sexa*(ta^2)) + (0.0014*(ta^2)*seasa))
    tbcc=-35.06997 + 1*tbc #updated 1 june also 34.83545 is mean of all tb
    tbccmin=-35.06997 + 1*tbmin
    
    #metabolic rate equations
    rmr_m18=(528.4166 + (3.7646*speaka) + (-30.7936*ta) + (0.4568*(ta^2)) + (-119.6472*tbcc) + 
               (42.7386*sexa) + (65.2184*seasa) + (-165.5823*sexa*seasa) + 
               (-4.2639*ta*seasa) + (-2.2128*ta*sexa) + (21.0541*tbcc*seasa) + 
               (1.9198*speaka*tbcc) + (5.2976*ta*sexa*seasa))
    
    bmrmin_m18=min(rmr_m18)
    
    
    bmrmin=bmrmin_m18
    bmrw=bmrmin/3600*20.9116
    
    
    rmr_stat=rmr_m18
    rmrw=rmr_stat/3600*20.9116 #rq 0.96 , 20.1 is rq 0.8 
    
    
    #posture=if ta is < tnz make it gmult min, if higher then gradually inc to gmult max
    x<-seq(tamin,max(ta),by=1)
    length(x)
    y<-seq(gmultmin,gmultmax,length.out=length(x))
    m1<-lm(y~x)
    coef<-(coefficients(m1))
    b=(coef[2])*ta+(coef[1])
    y <- ifelse((ta <tamin), gmultmin,  b)
    posture	= y #1.3 # Shape, ratio of long to short axis of a prolate ellipsoid
    #climate###
    
    airT	= ta# Air temperature (deg C)
    windspd	= rep(0.01,(length(ta)))# Wind speed (m/s)
    coreT=tb
    windspd	= windspd+input$windInput #0.01 seq(0, 10, 0)
    rh	= rep(input$rhInput,(length(ta)))# Relative humidity (%) seq(-30,100,30)
    mouseelephant <- bmrw*(q10^((tb-tbmin)/10)) #1.43*(3^((coreT-36.4)/10)) #change this in script too, this is 'minimum bmr' with a 'q10' - need to examine this vs using my equation
    mouseelephantmlh<-mouseelephant/ 20.9116 * 3600 
    sexseas=rep(as.character(mins$sexseas[mins$cat==category]),length(ta))
    data<-(cbind.data.frame(sexseas,airT,windspd,rh,coreT,rmr_stat,rmrw,mouseelephantmlh))
  
  
  heatstress <- function(posture, mass, coreT, furdepth, O2eff, furcond, airT, windspd, rh) {
    mouseelephant <- mouseelephant #1.43 #10^(-1.462 + 0.675 * log10(mass * 1000))
    a_coef <- 0.6
    b_coef <- 0.5
    sp_heat_air <- 1005.8
    volume <- mass / 1000
    b <- ((3 * volume) / (4 * 3.14159 * posture))^0.333
    c <- b
    a <- b * posture
    k_body <- 0.5 + (6.14 * b) + 0.439
    numerator <- a^2*b^2*c^2
    denominator <- a^2 * b^2 + a^2 * c^2 + b^2 * c^2
    Fraction <- numerator/denominator
    Rbody <- Fraction / (2 * k_body * volume)
    ao <- b*posture + furdepth/1000
    bo <- b + furdepth/1000
    co <- c + furdepth/1000
    Ecc_outr <- sqrt(ao^2 - co^2) / ao
    Aouter <- 2 * pi * bo^2 + 2 * pi * ((ao*bo)/Ecc_outr) * asin(Ecc_outr)
    Rinsul <- (bo - b)/(furcond * Aouter)
    DRYAIR=function (db = db, bp = 0, alt = 0) {
      tstd = 273.15
      pstd = 101325
      patmos = pstd * ((1 - (0.0065 * alt/288))^(1/0.190284))
      bp = rep(bp, length(patmos))
      bp[bp <= 0] = patmos[bp <= 0]
      densty = bp/(287.04 * (db + tstd))
      visnot = 1.8325e-05
      tnot = 296.16
      c = 120
      visdyn = (visnot * ((tnot + c)/(db + tstd + c))) * (((db + 
                                                              tstd)/tnot)^1.5)
      viskin = visdyn/densty
      difvpr = 2.26e-05 * (((db + tstd)/tstd)^1.81) * (1e+05/bp)
      thcond = 0.02425 + (7.038e-05 * db)
      htovpr = 2501200 - 2378.7 * db
      tcoeff = 1/(db + tstd)
      ggroup = 0.0980616 * tcoeff/(viskin * viskin)
      bbemit = 5.670367e-08 * ((db + tstd)^4)
      emtmax = 0.002897/(db + tstd)
      return(list(patmos = patmos, densty = densty, visdyn = visdyn, 
                  viskin = viskin, difvpr = difvpr, thcond = thcond, htovpr = htovpr, 
                  tcoeff = tcoeff, ggroup = ggroup, bbemit = bbemit, emtmax = emtmax))
    }
    dryair<-(DRYAIR(db=airT))
    visc_air <- dryair$visdyn
    k_air <- dryair$thcond
    den_air <- dryair$densty
    
    volcheck <- (4/3) * 3.14159 * a * b * c
    CharDimens <- volcheck^0.333
    Eccentricity <- sqrt(a^2 - c^2) / a
    area <- 2 * pi * b^2 + 2 * pi * ((a * b) / Eccentricity) * asin(Eccentricity)
    Re_number <- den_air * windspd * CharDimens/visc_air
    Pr_number <- (visc_air * sp_heat_air) / k_air
    q3p_num <- 2 * area * k_body * k_air * (2 + a_coef * (Re_number^b_coef)*Pr_number^0.333)*(coreT - airT)
    q3p_denom <- 2 * k_body * CharDimens * volcheck + area * Fraction * k_air * (2 + (a_coef * Re_number^b_coef) * Pr_number^0.333)
    g_in_air <- q3p_num/q3p_denom
    skinT <- coreT - (g_in_air * Fraction) / (2 * k_body)
    Gr_number <- abs(((den_air^2)*(1/(airT+273.15))*9.80665*(CharDimens^3)*(skinT - airT))/(visc_air^2))
    Nufree <- 2 + 0.6 * ((Gr_number^0.25) * (Pr_number^0.333))
    Nuforced <- 0.37 * Re_number^0.6
    Nutotal <- (Nufree^3 + Nuforced^3)^(1/3)
    hc <- Nutotal * k_air/CharDimens
    Rconv <- 1 / (hc * Aouter)
    Rrad <- 1 / (4 * Aouter * 1 * 0.95 * (5.7 * 10^-8) * (airT + 273.15)^3)
    Rtotal <- Rbody + Rinsul + (Rconv*Rrad)/(Rconv + Rrad)
    upcrit <- coreT - (mouseelephant*0.6*Rtotal) #Niche UCT = 'warm' point where heat generated is less than 60% of BMR  
    lowcrit <- coreT - mouseelephant * Rtotal
    Qgen <- (coreT - airT) / Rtotal
    QgenFinal <- ifelse(Qgen < mouseelephant, mouseelephant, Qgen)
    mlO2ph <- QgenFinal / 20.9116 * 3600 #20.1 assumes rq of 0.8
    VAPPRS=function (db = db)   {
      t = db + 273.16
      loge = t
      loge[t <= 273.16] = -9.09718 * (273.16/t[t <= 273.16] - 1) - 
        3.56654 * log10(273.16/t[t <= 273.16]) + 0.876793 * (1 - 
                                                               t[t <= 273.16]/273.16) + log10(6.1071)
      loge[t > 273.16] = -7.90298 * (373.16/t[t > 273.16] - 1) + 
        5.02808 * log10(373.16/t[t > 273.16]) - 1.3816e-07 * 
        (10^(11.344 * (1 - t[t > 273.16]/373.16)) - 1) + 0.0081328 * 
        (10^(-3.49149 * (373.16/t[t > 273.16] - 1)) - 1) + log10(1013.246)
      esat = (10^loge) * 100
      return(esat)
    }
    esat <- VAPPRS(coreT)
    WETAIR=function (db = db, wb = db, rh = 0, dp = 999, bp = 101325)    {
      tk = db + 273.15
      esat = VAPPRS(db)
      if (dp < 999) {
        e = VAPPRS(dp)
        rh = (e/esat) * 100
      }
      else {
        if (min(rh) > -1) {
          e = esat * rh/100
        }
        else {
          wbd = db - wb
          wbsat = VAPPRS(wb)
          dltae = 0.00066 * (1 + 0.00115 * wb) * bp * wbd
          e = wbsat - dltae
          rh = (e/esat) * 100
        }
      }
      rw = ((0.62197 * 1.0053 * e)/(bp - 1.0053 * e))
      vd = e * 0.018016/(0.998 * 8.31434 * tk)
      tvir = tk * ((1 + rw/(18.016/28.966))/(1 + rw))
      tvinc = tvir - tk
      denair = 0.0034838 * bp/(0.999 * tvir)
      cp = (1004.84 + (rw * 1846.4))/(1 + rw)
      if (min(rh) <= 0) {
        wtrpot = -999
      }
      else {
        wtrpot = 461500 * tk * log(rh/100)
      }
      return(list(e = e, esat = esat, vd = vd, rw = rw, tvinc = tvinc, 
                  denair = denair, cp = cp, wtrpot = wtrpot, rh = rh))
    }
    Qresp_gph <- (mlO2ph/0.2094/O2eff) * (WETAIR(db = coreT, rh = 100)$vd - WETAIR(db = airT, rh = rh)$vd)/1000 #this is all new
    conv_H2O_loss <- 2501200 - 2378.7 * airT
    Qresp_W <- ((Qresp_gph / 3600) * conv_H2O_loss) / 1000
    Qresp_kjph <- Qresp_W / 1000 * 3600
    PctBasal <- QgenFinal / mouseelephant * 100
    status <- ifelse(Qgen > mouseelephant, 1, ifelse(Qgen < 0.6 * mouseelephant, 3, 2)) # 1 = cold, 2 = happy, 3 = stress, stress=0.6
    H2Oloss_W <- (Qgen * -1) + mouseelephant
    H2O_gph <- (((H2Oloss_W) * 1000) / conv_H2O_loss) * 3600
    massph_percent <- ifelse(H2O_gph < 0, 0, ((H2O_gph / 1000) / mass) * 100)
    timetodeath <- ifelse(H2O_gph < 0, NA, 1 / (H2O_gph / (mass * 0.15 * 1000))) #0.15% of mass
    #newstuff:
    wet=(area*0.075) #m2 - 48cm2=12% of 'area' but wet area is 7.5% of sa with limbs so maybe reduce the amount wet that?  
    wetcm=wet*10000
    lick=wet*((furdepth/1000)*0.025)#m3 %5 of fur depth is about 1mm high, .25% is about 0.5mm
    lick=lick*1000000#g up to 3.6g
    #probability of licking is:
    pL=0.0007*(ta^2)-(0.0156*ta)+0.1098
    lick=lick*pL #grams of water lost when licking 
    esat=esat*0.00750062
    e=WETAIR(db=airT,rh=rh)$e #vap press air pascals
    e=e* 0.00750062 #mmHg
    ke=0.446*(windspd*60)^(0.634) #from Clifford et al 1959
    qe=ke*(esat-e) #kcal/h #heat loss from evaporation
    qe= (qe*1000)*0.00116298 #W/m2
    wetLW=qe*wet # in watts/m2
    evapgph<-(((wetLW) * 1000) / conv_H2O_loss) * 3600 #this is water loss from licking assuming they only replace as much water as is lost by evaporation 
    
    lick[lick<0] = 0
    evapgph[evapgph<0] = 0
    H2O_gph[H2O_gph<0] = 0
    Qresp_gph[Qresp_gph<0] = 0
    
    wtr=ifelse(((lick-evapgph)>0),(H2O_gph+(lick-evapgph)),H2O_gph) 
    all_wtr=wtr + Qresp_gph
    
    
    return(cbind.data.frame(UpperCritTemp=upcrit, LowerCritTemp=lowcrit, Qresp_gph=Qresp_gph, 
                            Qresp_W=Qresp_W, Qresp_kjph=Qresp_kjph, Tskin=skinT, Qgen=Qgen, 
                            QgenFinal=QgenFinal, mlO2ph=mlO2ph, PctBasal=PctBasal, 
                            status=status, H2Oloss_W=H2Oloss_W, H2O_gph=H2O_gph, 
                            massph_percent=massph_percent, timetodeath=timetodeath,
                            lick=lick,evapgph=evapgph,wtr=wtr,all_wtr=all_wtr))
  }
  
  run<-heatstress(posture, mass, coreT, furdepth, O2eff, furcond,airT,windspd,rh)
  allout<-cbind.data.frame(data,run)
  
  allout$MR_kjph <- allout$QgenFinal / 1000 * 3600

